# -*- coding: utf-8 -*-

import requests
import random
import json
from hashlib import md5
import os
import sys
# 初始化一个空字符串用于后续存储绝对路径
abs_path = '..'

# 检查程序是否被pyInstaller等工具冻结
if getattr(sys, 'frozen', False):
    # 如果程序被冻结，获取执行文件的绝对路径
    abs_path = os.path.dirname(os.path.abspath(sys.executable))
elif __file__:
    # 如果程序未被冻结，获取当前文件的绝对路径
    abs_path = os.path.dirname(os.path.abspath(__file__))


# 读取key.json文件获取appid和appkey
json_path = os.path.join(abs_path,'key.json')
with open(json_path, 'r', encoding='utf-8') as f:
        json_data = json.load(f)

# 从json文件中获取appid和appkey
appid = json_data['app_id']
appkey = json_data['app_key']

# 定义源语言和目标语言代码
from_lang = 'zh'
to_lang =  'en'

# 定义百度翻译API的Endpoint和请求路径
endpoint = 'http://api.fanyi.baidu.com'
path = '/api/trans/vip/translate'
url = endpoint + path

def run(query):
    """
    主函数，用于执行翻译任务。
    
    参数:
    - query: 待翻译的字符串
    
    返回值:
    - result_text: 翻译后的文本
    """
    # 生成签名和盐值
    def make_md5(s, encoding='utf-8'):
        return md5(s.encode(encoding)).hexdigest()
    
    # 判断输入字符串是否包含中文
    if is_chinese(query):
        salt = random.randint(32768, 65536)
        sign = make_md5(appid + query + str(salt) + appkey)

        # 构建请求参数
        headers = {'Content-Type': 'application/x-www-form-urlencoded'}
        payload = {'appid': appid, 'q': query, 'from': from_lang, 'to': to_lang, 'salt': salt, 'sign': sign}

        # 发送翻译请求并处理应答
        r = requests.post(url, params=payload, headers=headers)
        result = r.json()

        result_text = ''
        for t in result['trans_result']:
            result_text += t['dst']
    else:
        result_text = query

    return result_text

    
def is_chinese(uchar):
    """
    判断一个字符是否为中文。
    
    参数:
    - uchar: 待判断的字符
    
    返回值:
    - True: 如果字符是中文
    - False: 如果字符不是中文
    """
    if uchar >= u'\u4e00' and uchar <= u'\u9fa5':
        return True
    else:
        return False

if __name__ == '__main__':
    # 测试代码
    query = '你好'
    text = run(query)
    print(text)